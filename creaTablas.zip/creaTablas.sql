DROP TABLE IF EXISTS datos CASCADE;
DROP TABLE IF EXISTS vehiculos CASCADE;
DROP TABLE IF EXISTS tipos CASCADE;

--Tipos de vehiculos y sus velocidades maximas
CREATE TABLE tipos (
  tipo VARCHAR NOT NULL,
  vmax INTEGER,
  PRIMARY KEY(tipo)
);

--Vehiculos existentes
CREATE TABLE vehiculos (
  matricula VARCHAR NOT NULL,
  tipo VARCHAR NOT NULL,
  PRIMARY KEY(matricula),
  FOREIGN KEY(tipo) REFERENCES tipos(tipo)
);

--Datos guardados de los vehiculos suscritos
CREATE TABLE datos (
  id BIGSERIAL,
  matricula VARCHAR NOT NULL,
  latitud FLOAT NOT NULL,
  longitud FLOAT NOT NULL,
  altitud FLOAT NOT NULL,
  velocidad FLOAT NOT NULL,
  direccion FLOAT NOT NULL,
  subida FLOAT NOT NULL,
  rx FLOAT NOT NULL,
  ry FLOAT NOT NULL,
  fecha CHAR(10) NOT NULL,
  hora CHAR(8) NOT NULL,
  PRIMARY KEY(id),
  FOREIGN KEY(matricula) REFERENCES vehiculos(matricula)
);

--Clasificacion de vehiculos existentes y sus vmax (fuente: Ministerio del Interior)
\copy tipos from ./tipos.txt
